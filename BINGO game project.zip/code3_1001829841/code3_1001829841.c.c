//name-araohat kokate ID-1001829841
#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void fillbingo(int a1[5][5]);
int check(int a1[5][5],int);
void printbingo(int a1[5][5]);
int picknumber(int a2[75],int g);
int exist(int a1[5][5],int b);
int check_row(int a1[5][5]);
int check_diagonal(int a1[5][5]);
int check_column(int a1[5][5]);

void fillbingo(int a1[5][5])
{
    srand(time(0));
    int a2[75]={};
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<5;j++)
        {
            int n= rand()%15+ 15*i + 1 ;
            int h=check(a1,n);
            if(h==0)
            {
                a1[j][i]=n;
            }
            else
            {
                j--;
            }
        }
    }
    a1[2][2]=0;
}

int check(int a1[5][5],int l)
{
    int k=0;
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<5;j++)
        {
            if(l==a1[i][j])
            {
                k=1;
            }
        }
    }
    return k;
}

void printbingo(int a1[5][5])
{
    printf("%9c%16c%16c%16c%16c\n",'B','I','N','G','O');
    for(int k=0;k<76;k++)
    {
        printf("-");
    }
    printf("\n");
    for(int i=0;i<5;i++)
    {
        printf("|\t");
        for(int j=0;j<5;j++)
        {
            if(a1[i][j]!=0)
            {
                printf("%2d |\t",a1[i][j]);
                printf("\t");
            }
            else
            {
                printf("X");
                printf("  |\t\t");
            }
        }
        printf("\n");
        for(int f=0;f<76;f++)
        {
            printf("-");
        }
        printf("\n");
    }
}
int picknumber(int a2[75],int g)
{
   for(int i=0;i<75;i++)
   {
       if(a2[i]==g)
       {
           a2[i]=rand()%75 + 1;
           g=a2[i];
       }
   }
   return g;
}

int exist(int a1[5][5],int b)
{
    int flag;
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<5;j++)
        {
            if(b==a1[i][j])
            {
                a1[i][j]=0;
                flag=1;
            }
            else
            {
                flag=0;
            }
        }
    }
    return flag;
}

int check_row(int a1[5][5])
{
    int k=0;
    for(int i=0;i<5;i++)
    {
        if(a1[i][0]==0&&a1[i][1]==0&&a1[i][2]==0&&a1[i][3]==0&&a1[i][4]==0)
        {
           k=1;
           printf("You filled out a row-BINGO!!");
        }
    }
    return k;
}

int check_column(int a1[5][5])
{
    int l=0;
    for(int j=0;j<5;j++)
    {
        if(a1[0][j]==0&&a1[1][j]==0&&a1[2][j]==0&&a1[3][j]==0&&a1[4][j]==0)
        {
            l=1;
            printf("You filled out a column-BINGO!!");
        }
    }
    return l;
}

int check_diagonal(int a1[5][5])
{
    int m=0;
    if((a1[0][0]==0&&a1[1][1]==0&&a1[2][2]==0&&a1[3][3]==0&&a1[4][4]==0)||(a1[0][4]==0&&a1[1][3]==0&&a1[2][2]==0&&a1[3][1]==0&&a1[4][0]==0))
    {
      m=1;
      printf("You filled out a diagonal-BINGO!!");
    }
    return m;
}

int main()
{
    srand(time(0));
    int a1[5][5]= { };
    int a2[75]={ };
    int d,e,f,g,h;
    char ans;
    fillbingo(a1);
    printbingo(a1);
    for(int i=0;i<75;i++)
    {
       a2[i]=rand()%75 + 1;
    }
    while(f!=1&&g!=1&&h!=1)
    {
        e=rand()%75 + 1;
        d=picknumber(a2,e);
        if(d>0&&d<16)
        {
           printf("The next number is B%d\n",d);
        }
        else if(d>15&&d<31)
        {
           printf("The next number is I%d\n",d);
        }
        else if(d>30&&d<46)
        {
           printf("The next number is N%d\n",d);
        }
        else if(d>45&&d<61)
        {
           printf("The next number is G%d\n",d);
        }
       else if(d>60&&d<76)
        {
           printf("The next number is O%d\n",d);
        }
        printf("\nDo you have it? (Y/N)");
        scanf(" %c",&ans);
        printf("\n");
        if(ans == 'Y')
        {
            if(exist(a1,d)==1)
            {
                printf("That value is not on your bingo card- are you trying to cheat?\n");
                printf("\n");
            }
           else if(exist(a1,d)!=1)
           {
             printbingo(a1);
             printf("\n");
           }
        }
        else if(ans == 'N')
        {
            printbingo(a1);
        }
        f=check_row(a1);
        g=check_column(a1);
        h=check_diagonal(a1);
    }
    printf("\n");
    return 0;
}











