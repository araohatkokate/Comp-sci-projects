//name- araohat kokate ID-1001829841
#include <stdio.h>
#define BITS 8
void ConvertDecimalToBinary(int b, char conv[]);
int main()
{   int a1,a2,a3;
    char op[3];
    char DecB1[BITS]={};
    char DecB2[BITS]={};
    char DecB3[BITS]={};
    printf("BitWise Calculator\n\n");
    printf("Enter two base 10 values with a bitwise operator to see the decimal result and the binary result. The format is\n\nFirstNumber BitwiseOperator SecondNumber\n\n");
    printf("For example, enter the expression\n\n");
    printf("2 & 3\n\n");
    printf("This calculator can be used with &,|,^,<< and >>\n\n");
    printf("Please note that the spaces between numbers and operator is essential and the two entered values must be between 0 and 255\n\n");
    printf("Enter the expression\n\n");
    scanf("%d %s%d",&a1,op,&a2);
    while((a1<0||a1>255)||(a2<0||a2>255))
    {
      printf("The entered expression contains out of range values.\nPlease renter the expression using values between 0 and 255.\n");
      printf("Enter the expression\n");
      scanf("%d %s%d",&a1,op,&a2);
    }
    printf("\nIn Base 10...\n\n");
    if(op[0]=='&')
    {
        printf("%d %s %d = %d\n\n",a1,op,a2,a1 & a2);
        a3 = a1 & a2;
    }
    else if(op[0]=='|')
    {
        printf("%d %s %d = %d\n\n",a1,op,a2,a1 | a2);
        a3 = a1 | a2;
    }
    else if(op[0]=='^')
    {
        printf("%d %s %d = %d\n\n",a1,op,a2,a1 ^ a2);
        a3 = a1 ^ a2;
    }
    else if(op[0]=='>')
    {
        printf("%d %s %d = %d\n\n",a1,op,a2,a1 >> a2);
        a3 = a1 >> a2;
        printf("In 8-bit base 2...\n");
        ConvertDecimalToBinary(a1,DecB1);
        printf("%s ",DecB1);
        printf("%s %d",op,a2);
        ConvertDecimalToBinary(a3,DecB3);
        printf("========\n");
        printf("%s\n",DecB3);
        return 0;
    }
    else if(op[0]=='<')
    {
        printf("%d %s %d = %d\n\n",a1,op,a2,a1 << a2);
        a3 = a1 << a2;
        printf("In 8-bit base 2...\n");
        ConvertDecimalToBinary(a1,DecB1);
        printf("%s ",DecB1);
        printf("%s %d",op,a2);
        ConvertDecimalToBinary(a3,DecB3);
        printf("========\n");
        printf("%s\n",DecB3);
        return 0;
    }
    else
    {
        printf("operator %c is not supported by the calculator",op[0]);
        return 0;
    }
    printf("\nIn 8-bit base 2...\n\n");
    ConvertDecimalToBinary(a1,DecB1);
    printf("%s\n",DecB1);
    printf("%c",op[0]);
    ConvertDecimalToBinary(a2,DecB2);
    printf("%s\n",DecB2);
    ConvertDecimalToBinary(a3,DecB3);
    printf("========\n");
    
    printf("%s\n",DecB3);
    return 0;
    
}
void ConvertDecimalToBinary(int b, char conv[])
{
    int t[BITS];
    t[0]= b;
    int i;
    for(i=1;i<BITS;i++)
    {
        t[i]=b>>1;
        b=t[i];
    }
    for(i=0;i<BITS;i++)
    {
        t[i]=t[i]&1;
        
    }
    for(int i=0;i<BITS;i++)
    {
        conv[i]=t[BITS-1-i]+48;
    }
    printf("\n");
}


