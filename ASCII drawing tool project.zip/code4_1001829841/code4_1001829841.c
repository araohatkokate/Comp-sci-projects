#include <stdio.h>
#include "DrawTool.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#define MAX 20
int main()
{
    int Size;
    char *Token1=NULL;
    char fl[MAX],ll[MAX];
    char a[MAXMAPSIZE][MAXMAPSIZE]={ };
    char b[MAX];
    char input,input1;
    InitializeMap(a,&Size);
    PrintInstructions();
    PrintMap(a,Size);
    printf("Enter draw command (enter Q to quit) ");
    fgets(b,MAX-1,stdin);
    Token1=strtok(b,"(),");
    strcpy(fl, Token1);
    input=toupper(fl[0]);

    while(input!='Q')
    {
        char *Token2=NULL;
        Token2=strtok(NULL,"(),");
        int row=atoi(Token2);
        if(row>=Size)
        {
            printf("the draw command is out of range");
        }
        char *Token3=NULL;
        Token3=strtok(NULL,"(),");
        int column=atoi(Token3);
        if(column>=Size)
        {
            printf("the draw command is out of range");
        }
        char *Token4=NULL;
        Token4=strtok(NULL,"(),");
        int mark=atoi(Token4);
        if(mark>=Size)
        {
            printf("the draw command is out of range");
        }
        char *Token5=NULL;
        Token5=strtok(NULL,"(),");
        strcpy(ll, Token5);
        if(ll[0]==10)
        {
           ll[0]='X';
        }
        DrawLine(a,row,column,fl[0],mark,ll[0]);
        PrintMap(a,Size);
        printf("Enter draw command (enter Q to quit) ");
        fgets(b,MAX-1,stdin);
        char *Token6=NULL;
        Token6=strtok(b,"(),");
        strcpy(fl, Token6);
        input=toupper(fl[0]);

    }
    return 0;
}
